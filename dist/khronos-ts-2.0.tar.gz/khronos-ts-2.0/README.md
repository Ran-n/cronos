# khronos-ts
Python program with my own way of representing time as a int number  
Programa en python para representar as datas  
Programa en python para representar las fechas  

----
Example:  
Exemplo:  
Ejemplo:  
2019/07/10 09:55:00:000000  
+20190710095500000000  
\+ 2019 07 10 09 55 00 000000  

-(0)        → a.C                       → 1bit  
or/ou/o  
+(1)        → d.C                       → Same bit/Mesmo bit/Mismo bit  
2019        → year/ano/año              → 5bits  
07          → month/mes                 → 2bits  
10          → day/día                   → 2bits  
55          → minute/minuto             → 2bits  
00          → second/segundo            → 2bits  
000000      → microsecond/microsegundo  → 6bits  

## Donations 🙇🙇‍♀

**Bitcoin** <img src="https://raw.githubusercontent.com/Ran-n/svgs/main/divisas/bitcoin/bitcoin_0.svg" width="20" alt="bitcoin logo" title="Bitcoin">  
bc1q79vja8jzr27dxaf3ylu7e49ady8zq0jsm5qfk6

**Monero** <img src="https://raw.githubusercontent.com/Ran-n/svgs/main/divisas/monero/monero_0.svg" width="20" alt="monero logo" title="Monero">  
88Rezd6ZQzaCb1s7K1tRCiCaDzuHrfYsn4q348jJuePpLs84JNsWEghMAZZgzpDPrqD4PBxk7hwMkSdNQ4CLqFHyPVLdX1D

**Wownero** <img src="https://raw.githubusercontent.com/Ran-n/svgs/main/divisas/wownero/wownero_0.svg" width="20" alt="wownero logo" title="Wownero">  
WW2RheTNrq8goAi42Dz5AKUj1qLSaTSSgiH7sHR2qRqojg238EXP3MM3xuUgswriET7UrpkEoYaCkecBhnU49oxM1dZyYoSmm
