'''
info kronus
'''

__name__ = 'kronus'
__version__ = '2.2'
__author__ = 'Ran#'
__credits__ = 'Ran#'
__license__ = 'GPLv3'
